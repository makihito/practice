<?php
header('Location: https://h2o-space.com');
exit();
